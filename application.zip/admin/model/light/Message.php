<?php

namespace app\admin\model\light;

use think\Model;


class Message extends Model
{

    

    

    // 表名
    protected $name = 'light_message';

    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [

    ];
    

    







}
