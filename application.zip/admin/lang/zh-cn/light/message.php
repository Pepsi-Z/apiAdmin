<?php

return [
    'Id'         => 'ID',
    'Msgtype'    => '推送类型',
    'Deviceid'   => '集中器设备序列号',
    'Nodeid'     => '节点设备序列号',
    'Content'    => '内容',
    'Status'     => '状态（1告警2通知）',
    'Createtime' => '创建时间'
];
