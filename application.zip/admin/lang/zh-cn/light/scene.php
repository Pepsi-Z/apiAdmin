<?php

return [
    'Id'          => 'ID',
    'Crontab_ids' => '定时任务ID(多选)',
    'Title'       => '标题',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间',
    'Deletetime'  => '删除时间'
];
