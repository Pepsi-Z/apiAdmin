<?php

return [
    'Id'               => 'ID',
    'Title'            => '隧道名称',
    'Tunnel_number'    => '隧道编号',
    'City'             => '省市',
    'Stake_mark_start' => '起点桩号',
    'Stake_mark_end'   => '终点桩号',
    'Endlong'          => '全长（km）',
    'Direction'        => '方向',
    'Operationtime'    => '通车时间',
    'Createtime'       => '创建时间',
    'Updatetime'       => '更新时间'
];
