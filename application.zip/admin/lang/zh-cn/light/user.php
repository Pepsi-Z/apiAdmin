<?php

return [
    'Id'         => 'ID',
    'Username'   => '用户名',
    'Name'       => '真实姓名',
    'Password'   => '密码',
    'Mobile'     => '手机号',
    'Prevtime'   => '上次登录时间',
    'Loginip'    => '登录IP',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Status'     => '状态',
    'State 0'             => '禁用',
    'State 1'             => '正常',
];
