<?php

return [
    'Id'          => 'ID',
    'Title'       => '标题',
    'Deviceid'    => '集中器设备序列号',
    'Jobsnum'     => '任务编号（1~255）',
    'Controltype' => '控制类型1继电器控制2调光控制3断路器控制',
    'Radio'       => '是否广播（即所有分组）',
    'Groupnum'    => '分组号：1~255（非广播时该值必填）',
    'Ab'          => '控制AB灯：1-A灯,2-B灯,3-AB灯',
    'Luminance'   => '调光亮度百分比,0~100%',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间',
    'Deletetime'  => '删除时间'
];
