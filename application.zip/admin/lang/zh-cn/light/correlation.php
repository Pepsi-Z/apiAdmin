<?php

return [
    'Id'              => 'ID',
    'Type'            => '1集中器 2分组 3节点',
    'Concentrator_id' => '集中器ID',
    'Group_id'        => '分组ID',
    'Node_id'         => '节点ID',
    'Model_id'        => '模型ID',
    'Createtime'      => '创建时间',
    'Updatetime'      => '更新时间'
];
